
// TripBook Manager Validation

const searchForm = document.getElementById("searchForm");
const updateForm = document.getElementById("updateForm");

// Regular Expressions
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const namePattern = /^[A-Za-z ]+$/;
const bookingPattern = /^TB[0-9]{4}$/;


// Show live error message
function showError(id, message) {
    document.getElementById(id).innerHTML = message;
}


// 1. Booking Search Validation
searchForm.addEventListener("submit", function(e) {

    let id = document.getElementById("searchBookingId").value.trim();

    if (!bookingPattern.test(id)) {
        e.preventDefault();
        showError("searchMessage", "❌ Enter a valid Booking ID (TB1001)");
        alert("Please enter a valid Booking ID!");
    }
    else {
        showError("searchMessage", "✔ Booking ID is valid!");
    }

});


// 2. Live Password Validation
document.getElementById("managerPassword").addEventListener("input", function() {

    let password = this.value;

    if (password.length < 6) {
        showError("passwordError", "❌ Password must contain at least 6 characters");
    }
    else if (!/[0-9]/.test(password)) {
        showError("passwordError", "❌ Password must contain at least one number");
    }
    else {
        showError("passwordError", "✔ Strong password!");
    }

});


// 3. Manager Name Live Validation
document.getElementById("managerName").addEventListener("input", function() {

    if (!namePattern.test(this.value)) {
        showError("nameMessage", "❌ Only letters are allowed!");
    }
    else {
        showError("nameMessage", "✔ Valid name");
    }

});


// 4. Submit Operations Update
updateForm.addEventListener("submit", function(e) {

    let name = document.getElementById("managerName").value.trim();
    let email = document.getElementById("managerEmail").value.trim();
    let password = document.getElementById("managerPassword").value;
    let operation = document.getElementById("operation").value;
    let reference = document.getElementById("bookingReference").value.trim();
    let notes = document.getElementById("notes").value.trim();

    let error = "";

    if (!namePattern.test(name) || name === "") {
        error = "Enter a valid manager name!";
    }
    else if (!emailPattern.test(email)) {
        error = "Enter a valid email address!";
    }
    else if (password.length < 6 || !/[0-9]/.test(password)) {
        error = "Enter a valid password!";
    }
    else if (operation === "") {
        error = "Please select an operation!";
    }
    else if (reference !== "" && !bookingPattern.test(reference)) {
        error = "Invalid booking reference!";
    }
    else if (notes.length < 10) {
        error = "Notes must contain at least 10 characters!";
    }

    if (error !== "") {
        e.preventDefault();
        showError("updateMessage", "❌ " + error);
        alert(error);
    }
    else {
        e.preventDefault();
        showError("updateMessage", "✔ All information is valid!");
        alert("Operations Update Successful!");
    }

});


// 5. Priority Change Event
document.getElementById("priority").addEventListener("change", function() {

    showError("priorityMessage",
        "Selected Priority: " + this.value.toUpperCase());

});


// 6. Clear messages after reset
updateForm.addEventListener("reset", function() {
    setTimeout(function() {
        document.querySelectorAll(".field-message, .validation-message")
            .forEach(function(item) {
                item.innerHTML = "";
            });
    }, 0);
});
