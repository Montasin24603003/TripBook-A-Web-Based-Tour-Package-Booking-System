// TripBook - Admin Registration Form Validation

document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("registrationForm");

    function showError(id, message) {
        document.getElementById(id).innerHTML = message;
    }

    function clearMessages() {
        document.querySelectorAll(".error").forEach(function (item) {
            item.innerHTML = "";
        });
        document.getElementById("formMessage").innerHTML = "";
    }

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        clearMessages();

        const fullname = document.getElementById("fullname").value.trim();
        const email = document.getElementById("email").value.trim();
        const phone = document.getElementById("phone").value.trim();
        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value;
        const confirmPassword = document.getElementById("confirmPassword").value;

        let hasError = false;

        function error(id, message) {
            showError(id, message);
            hasError = true;
        }

        // Common validation rules
        if (!/^[A-Za-z ]+$/.test(fullname)) error("fullnameError", "Name should contain only letters and spaces.");
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) error("emailError", "Enter a valid email address.");
        if (!/^[0-9]{11}$/.test(phone)) error("phoneError", "Phone number must contain exactly 11 digits.");
        if (username.length < 4) error("usernameError", "Username must contain at least 4 characters.");
        if (password.length < 6 || !/[0-9]/.test(password)) error("passwordError", "Password must contain at least 6 characters and one number.");
        if (password !== confirmPassword) error("confirmPasswordError", "Passwords do not match.");

        // Category-specific validation
        
        const adminid = document.getElementById("adminid").value.trim();
        const department = document.getElementById("department").value;
        const joiningdate = document.getElementById("joiningdate").value;
        if (!/^ADM-[0-9]{4,6}$/i.test(adminid)) showError("adminidError", "Admin ID must be like ADM-1001.");
        if (!department) showError("departmentError", "Please select a department.");
        if (!joiningdate || new Date(joiningdate + "T00:00:00") > new Date(new Date().toDateString()))
            showError("joiningdateError", "Enter a valid joining date (not in the future).");
        

        if (hasError) {
            document.getElementById("formMessage").innerHTML =
                '<p style="color:red;">Please correct the errors above.</p>';
        } else {
            document.getElementById("formMessage").innerHTML =
                '<p style="color:green; font-weight:bold;">Registration Successful!</p>';
            form.reset();
        }
    });

    form.addEventListener("reset", function () {
        setTimeout(clearMessages, 0);
    });

    // Change event: clear the related error when the user edits a field
    form.addEventListener("change", function (event) {
        const errorBox = document.getElementById(event.target.id + "Error");
        if (errorBox) errorBox.innerHTML = "";
        document.getElementById("formMessage").innerHTML = "";
    });
});
